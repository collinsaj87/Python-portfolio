# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
# make the weight inputs a function that can be used in the development

import csv
import tkinter
import matplotlib
matplotlib.use('TkAgg')

#geo = 0
geo_env = []
pop_env = []
trans_env = []
geo_w = []
pop_w = []
trans_w = []
weight1 = 0.4
weight2 = 0.3
weight3 = 0.3


fig = matplotlib.pyplot.figure(figsize=(6, 6))
ax = fig.add_axes([0, 0, 1, 1])


# importing the csv data from the geology map

with open ('geology.csv', newline='') as f:
    geo_env = []
    reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    for row in reader:
        rowlist = []
        geo_env.append(rowlist)
        for value in row:
           rowlist.append(value)

matplotlib.pyplot.imshow(geo_env)
#matplotlib.pyplot.show()

with open ('population.csv', newline='') as g:
    pop_env = []
    reader = csv.reader(g, quoting=csv.QUOTE_NONNUMERIC)
    for row in reader:
        rowlist = []
        pop_env.append(rowlist)
        for value in row:
            rowlist.append(value)
    matplotlib.pyplot.imshow(pop_env)
    #matplotlib.pyplot.show()

with open ('transport.csv', newline='') as h:
    trans_env = []
    reader = csv.reader(h, quoting=csv.QUOTE_NONNUMERIC)
    for row in reader:
        rowlist = []
        trans_env.append(rowlist)
        for value in row:
            rowlist.append(value)
    matplotlib.pyplot.imshow(trans_env)
f.close()
g.close()
h.close()

root = tkinter.Tk()
root.wm_title("Site location")
canvas = matplotlib.backends.backend_tkagg.FigureCanvasTkAgg(fig, master=root)
canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

#Test that slider values are being read << ensure that 'command = change' is entered in slider set up
#def change(val):
    #print(str(val))
    
def get_values():
    global geo
    geo = geo_slider.get() / 100
    

geo_slider = tkinter.Scale(root, from_ = 100, to = 0, label='Geology')
geo_slider.pack(padx=5, pady=15, side='left')

pop_slider = tkinter.Scale(root, from_ = 100, to = 0, label='Population')
pop_slider.pack(padx=5, pady=20, side='left')

trans_slider = tkinter.Scale(root, from_ = 100, to = 0, label ='Transport')
trans_slider.pack(padx=5, pady=25, side='left')

extract = tkinter.Button(root, text = 'Submit', command=get_values)
extract.pack()

tkinter.mainloop()


for j in geo_env: # come back to this and make it a function!
    geo_w = []
    for row in geo_env:
        rowlist = []
        geo_w.append(rowlist)
        for value in row:
            rowlist.append((geo * value))
print(geo_w)    
            

'''       
for j in pop_env: # come back to this and make it a function!
    pop_w = []
    for row in pop_env:
        rowlist = []
        pop_w.append(rowlist)
        for value in row:
            rowlist.append(weight2 * value)
            #print (pop_w)
            
for j in trans_env: # come back to this and make it a function!
    trans_w = []
    for row in trans_env:
        rowlist = []
        trans_w.append(rowlist)
        for value in row:
            rowlist.append(weight3 * value)
            #print (trans_w)

#matplotlib.pyplot.imshow(geo_w)
#matplotlib.pyplot.show()          
'''
 
